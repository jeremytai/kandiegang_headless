/**
 * Plugin Name: Kandie Gang GroupRide & Events Manager
 * Description: Multi-level ride management (7 spots per guide), Workshops, and "Human Ride" category. Unified for GraphQL.
 * Version: 4.2.9
 * Author: Kandie Kollektiv UG (haftungsbeschränkt)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter('upload_mimes', function($mimes) {
    // Allow both common GPX MIME types
    $mimes['gpx'] = 'application/gpx+xml';
    $mimes['gpxxml'] = 'application/gpx+xml';
    $mimes['application/gpx+xml'] = 'application/gpx+xml';
    $mimes['octet-stream'] = 'application/octet-stream';
    $mimes['application/octet-stream'] = 'application/octet-stream';
    return $mimes;
});

/**
 * 1. REGISTER CUSTOM POST TYPES
 */
add_action( 'init', function() {
    register_post_type( 'ride_guide', [
        'labels' => [ 'name' => 'Kandie Guides', 'singular_name' => 'Guide' ],
        'public' => true,
        'menu_icon' => 'dashicons-admin-users',
        'supports' => [ 'title', 'thumbnail' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideGuide',
        'graphql_plural_name' => 'rideGuides',
    ]);

    register_post_type( 'event', [
        'labels' => [ 
            'name' => 'Kandie Gang Events', 
            'singular_name' => 'Event',
            'add_new_item' => 'Add New Kandie Gang Event'
        ],
        'public' => true,
        'menu_icon' => 'dashicons-performance',
        'supports' => [ 'title', 'thumbnail', 'excerpt' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideEvent',
        'graphql_plural_name' => 'rideEvents',
    ]);
});

/**
 * 2. REGISTER ACF FIELDS
 */
add_action('acf/init', function() {
    if( !function_exists('acf_add_local_field_group') ) return;

    $fields = [];

    // --- BASIC CONFIG ---
    $fields[] = [
        'key' => 'field_primaryType',
        'label' => 'Event Type',
        'name' => 'primaryType',
        'type' => 'radio',
        'choices' => ['groupride' => 'Groupride', 'workshop' => 'Workshop'],
        'layout' => 'horizontal',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_rideCategory',
        'label' => 'Ride Category',
        'name' => 'rideCategory',
        'type' => 'select',
        'choices' => ['road' => 'Road', 'gravel' => 'Gravel', 'human_ride' => 'Human Ride'],
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_eventDate',
        'label' => 'Event Date',
        'name' => 'eventDate',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_rideTime',
        'label' => 'Ride Time',
        'name' => 'rideTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_publicReleaseDaysBefore',
        'label' => 'Public Release Days Before Event',
        'name' => 'publicReleaseDaysBefore',
        'type' => 'number',
        'instructions' => 'How many days before the event date should public registration open?',
        'default_value' => 7,
        'min' => 0,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_repeatingEvent',
        'label' => 'Repeating Event?',
        'name' => 'repeatingEvent',
        'type' => 'true_false',
        'ui' => 1,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_repeatUntil',
        'label' => 'Repeat Until',
        'name' => 'repeatUntil',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'conditional_logic' => [[['field' => 'field_repeatingEvent', 'operator' => '==', 'value' => '1']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_isFlintaOnly',
        'label' => 'FLINTA* Only?',
        'name' => 'isFlintaOnly',
        'type' => 'true_false',
        'ui' => 1,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_meetingPoint',
        'label' => 'Meeting Point',
        'name' => 'meetingPoint',
        'type' => 'group',
        'show_in_graphql' => true,
        'sub_fields' => [
            ['key' => 'f_mp_name', 'label' => 'Place Name', 'name' => 'name', 'type' => 'text', 'show_in_graphql' => true],
            ['key' => 'f_mp_street', 'label' => 'Street', 'name' => 'street', 'type' => 'text', 'show_in_graphql' => true],
            ['key' => 'f_mp_city', 'label' => 'City', 'name' => 'city', 'type' => 'text', 'show_in_graphql' => true],
        ],
    ];

    $fields[] = [
        'key' => 'field_rideTime',
        'label' => 'Ride Time',
        'name' => 'rideTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'show_in_graphql' => true,
    ];

    // --- WORKSHOP SPECIFIC FIELDS ---
    $fields[] = [
        'key' => 'field_workshopCapacity',
        'label' => 'Maximum Workshop Participants',
        'name' => 'workshopCapacity',
        'type' => 'number',
        'instructions' => 'Set the total number of spots available for this workshop.',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'workshop']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_workshopStartTime',
        'label' => 'Workshop Start Time',
        'name' => 'workshopStartTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'workshop']]],
        'show_in_graphql' => true,
    ];

    // --- RIDE LEVELS ---
    $levels = ['level1' => '1', 'level2' => '2', 'level2plus' => '2+', 'level3' => '3'];
    foreach ($levels as $name => $label) {
        $fields[] = [
            'key' => "field_group_$name",
            'label' => "Level $label Details",
            'name' => $name,
            'type' => 'group',
            'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
            'show_in_graphql' => true,
            'sub_fields' => [
                [
                    'key' => "f_{$name}_guides",
                    'label' => 'Guides (7 spots each)',
                    'name' => 'guides',
                    'type' => 'post_object',
                    'post_type' => ['ride_guide'],
                    'multiple' => 1,
                    'return_format' => 'object',
                    'ui' => 1,
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_distanceKm",
                    'label' => 'Distance (km)',
                    'name' => 'distanceKm',
                        'type' => 'number',
                        'required' => 0, // Default not required, will be conditionally required by JS
                        'min' => 0,
                        'step' => 0.1,
                        'show_in_graphql' => true,
                        'conditional_logic' => [
                            [
                                [
                                    'field' => "f_{$name}_guides",
                                    'operator' => '!=empty',
                                ]
                            ]
                        ],
                ],
                [
                    'key' => "f_{$name}_routeUrl",
                    'label' => 'Route URL',
                    'name' => 'routeUrl',
                    'type' => 'url',
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_gpxFile",
                    'label' => 'GPX File URL',
                    'name' => 'gpxFile',
                    'type' => 'url',
                    'show_in_graphql' => true,
                ],
            ],
        ];
    }

    // --- LOGISTICS & DESCRIPTION ---
    $fields[] = [
        'key' => 'field_description',
        'label' => 'Description (Markdown)',
        'name' => 'description',
        'type' => 'textarea',
        'show_in_graphql' => true,
    ];

    acf_add_local_field_group([
        'key' => 'group_ride_manager_final',
        'title' => 'Event Details',
        'fields' => $fields,
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'event']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'eventDetails',
    ]);

    acf_add_local_field_group([
        'key' => 'group_ride_guides_details',
        'title' => 'Guide Details',
        'fields' => [
            [
                'key' => 'field_guide_bio',
                'label' => 'Bio',
                'name' => 'bio',
                'type' => 'textarea',
                'show_in_graphql' => true,
            ],
            [
                'key' => 'field_guide_link',
                'label' => 'Link',
                'name' => 'link',
                'type' => 'text',
                'show_in_graphql' => true,
            ],
        ],
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'ride_guide']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'guideDetails',
    ]);
});

/**
 * 2.05 PUBLIC RELEASE DATE (COMPUTED)
 */
function kandie_calculate_public_release_date($post_id) {
    if (!function_exists('get_field')) {
        return null;
    }

    $event_date = get_field('eventDate', $post_id);
    if (!$event_date) {
        return null;
    }

    $days_before = get_field('publicReleaseDaysBefore', $post_id);
    if (!is_numeric($days_before)) {
        $days_before = 7;
    }

    $days_before = max(0, (int)$days_before);
    $event_date_obj = DateTimeImmutable::createFromFormat('Y-m-d', $event_date);
    if (!$event_date_obj) {
        return null;
    }

    return $event_date_obj->modify("-{$days_before} days")->format('Y-m-d');
}


add_action('graphql_register_types', function() {
    if (!function_exists('register_graphql_field')) {
        return;
    }

    // Existing publicReleaseDate field
    register_graphql_field('RideEvent', 'publicReleaseDate', [
        'type' => 'String',
        'resolve' => function($root) {
            $post_id = null;
            if (is_object($root) && isset($root->ID)) {
                $post_id = $root->ID;
            } elseif (is_object($root) && isset($root->databaseId)) {
                $post_id = $root->databaseId;
            }
            if (!$post_id) {
                return null;
            }
            return kandie_calculate_public_release_date($post_id);
        },
    ]);

    // New: Combined eventDate and rideTime as ISO8601 string
    register_graphql_field('RideEvent', 'eventDateTime', [
        'type' => 'String',
        'description' => 'Combined eventDate and rideTime as ISO8601 datetime string (UTC)',
        'resolve' => function($root) {
            $post_id = null;
            if (is_object($root) && isset($root->ID)) {
                $post_id = $root->ID;
            } elseif (is_object($root) && isset($root->databaseId)) {
                $post_id = $root->databaseId;
            }
            if (!$post_id) {
                return null;
            }
            if (!function_exists('get_field')) {
                return null;
            }
            $date = get_field('eventDate', $post_id); // Y-m-d
            $time = get_field('rideTime', $post_id); // H:i or H:i:s
            if (!$date || !$time) {
                return null;
            }
            // If time is H:i, add :00
            if (preg_match('/^\d{2}:\d{2}$/', $time)) {
                $time .= ':00';
            }
            // Combine and create DateTimeImmutable in UTC
            $dt = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', "$date $time", new DateTimeZone('UTC'));
            if (!$dt) {
                return null;
            }
            return $dt->format('c'); // ISO8601
        },
    ]);
});

/**
 * 2.07 ONE-TIME BACKFILL
 */
add_action('admin_init', function() {
    if (!is_admin()) {
        return;
    }

    if (get_option('kandie_backfill_20260212_done')) {
        return;
    }

    if (!function_exists('get_field') || !function_exists('update_field')) {
        return;
    }

    $event_ids = get_posts([
        'post_type' => 'event',
        'post_status' => 'any',
        'posts_per_page' => -1,
        'fields' => 'ids',
    ]);

    $levels = ['level1', 'level2', 'level2plus', 'level3'];

    foreach ($event_ids as $event_id) {
        $is_repeating = get_field('repeatingEvent', $event_id);
        if ($is_repeating && !get_field('repeatUntil', $event_id)) {
            update_field('repeatUntil', '2026-10-20', $event_id);
        }

        foreach ($levels as $level) {
            $group_value = get_field($level, $event_id);
            if (!is_array($group_value)) {
                continue;
            }

            if (!isset($group_value['distanceKm']) || $group_value['distanceKm'] === '' || $group_value['distanceKm'] === null) {
                $group_value['distanceKm'] = 60;
                update_field($level, $group_value, $event_id);
            }
        }
    }

    update_option('kandie_backfill_20260212_done', 1);
});

/**
 * 2.08 REPEAT TOOLS
 */
add_action('admin_menu', function() {
    add_submenu_page(
        'edit.php?post_type=event',
        'Repeat Tools',
        'Repeat Tools',
        'manage_options',
        'kandie-repeat-tools',
        'kandie_render_repeat_tools_page'
    );
});

function kandie_render_repeat_tools_page() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have permission to access this page.');
    }

    $regenerated = isset($_GET['kandie_regenerated']) ? (int)$_GET['kandie_regenerated'] : null;
    $deleted = isset($_GET['kandie_deleted']) ? (int)$_GET['kandie_deleted'] : null;

    echo '<div class="wrap">';
    echo '<h1>Repeat Tools</h1>';

    if ($regenerated !== null) {
        echo '<div class="notice notice-success"><p>Generated ' . esc_html($regenerated) . ' repeat events.</p></div>';
    }

    if ($deleted !== null) {
        echo '<div class="notice notice-success"><p>Deleted ' . esc_html($deleted) . ' draft repeat events.</p></div>';
    }

    echo '<p>Use these actions to regenerate or clean up repeating events.</p>';

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-bottom: 16px;">';
    wp_nonce_field('kandie_regenerate_repeats');
    echo '<input type="hidden" name="action" value="kandie_regenerate_repeats" />';
    submit_button('Regenerate Repeats', 'primary', 'submit', false);
    echo '</form>';

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('kandie_cleanup_repeats');
    echo '<input type="hidden" name="action" value="kandie_cleanup_repeats" />';
    submit_button('Delete Draft Repeats', 'secondary', 'submit', false);
    echo '</form>';

    echo '</div>';
}

add_action('admin_post_kandie_regenerate_repeats', function() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have permission to perform this action.');
    }

    check_admin_referer('kandie_regenerate_repeats');

    $event_ids = get_posts([
        'post_type' => 'event',
        'post_status' => 'any',
        'posts_per_page' => -1,
        'fields' => 'ids',
        'meta_key' => 'repeatingEvent',
        'meta_value' => '1',
    ]);

    $created = 0;
    foreach ($event_ids as $event_id) {
        $created += kandie_generate_repeats_for_post($event_id, true);
    }

    wp_safe_redirect(add_query_arg([
        'post_type' => 'event',
        'page' => 'kandie-repeat-tools',
        'kandie_regenerated' => $created,
    ], admin_url('edit.php')));
    exit;
});

add_action('admin_post_kandie_cleanup_repeats', function() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have permission to perform this action.');
    }

    check_admin_referer('kandie_cleanup_repeats');

    $repeat_ids = get_posts([
        'post_type' => 'event',
        'post_status' => 'draft',
        'posts_per_page' => -1,
        'fields' => 'ids',
        'meta_query' => [
            [
                'key' => '_repeat_source_id',
                'compare' => 'EXISTS',
            ],
        ],
    ]);

    $deleted = 0;
    foreach ($repeat_ids as $repeat_id) {
        $deleted += (int)wp_delete_post($repeat_id, true);
    }

    wp_safe_redirect(add_query_arg([
        'post_type' => 'event',
        'page' => 'kandie-repeat-tools',
        'kandie_deleted' => $deleted,
    ], admin_url('edit.php')));
    exit;
});

function kandie_generate_repeats_for_post($post_id, $force = false) {
    if (get_post_type($post_id) !== 'event') {
        return 0;
    }

    if (get_post_meta($post_id, '_repeat_source_id', true)) {
        return 0;
    }

    if (!function_exists('get_field') || !function_exists('get_fields') || !function_exists('update_field')) {
        return 0;
    }

    $is_repeating = get_field('repeatingEvent', $post_id);
    if (!$is_repeating && !$force) {
        return 0;
    }

    $event_date = get_field('eventDate', $post_id);
    $end_date_value = get_field('repeatUntil', $post_id);
    if (!$event_date || !$end_date_value) {
        return 0;
    }

    $start_date = DateTimeImmutable::createFromFormat('Y-m-d', $event_date);
    $end_date = DateTimeImmutable::createFromFormat('Y-m-d', $end_date_value);

    if (!$start_date || !$end_date || $start_date > $end_date) {
        return 0;
    }

    if (!$force) {
        $generated_until = get_post_meta($post_id, '_repeat_generated_until', true);
        if ($generated_until) {
            $generated_until_date = DateTimeImmutable::createFromFormat('Y-m-d', $generated_until);
            if ($generated_until_date && $generated_until_date >= $end_date) {
                return 0;
            }
        }
    }

    $source_post = get_post($post_id);
    if (!$source_post) {
        return 0;
    }

    $fields = get_fields($post_id);
    if (!$fields) {
        $fields = [];
    }

    $created = 0;
    for ($next_date = $start_date->modify('+7 days'); $next_date <= $end_date; $next_date = $next_date->modify('+7 days')) {
        $next_date_value = $next_date->format('Y-m-d');

        $existing = new WP_Query([
            'post_type' => 'event',
            'post_status' => 'any',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [
                [
                    'key' => '_repeat_source_id',
                    'value' => $post_id,
                    'compare' => '=',
                ],
                [
                    'key' => 'eventDate',
                    'value' => $next_date_value,
                    'compare' => '=',
                ],
            ],
        ]);

        if ($existing->have_posts()) {
            continue;
        }

        $new_post_id = wp_insert_post([
            'post_type' => 'event',
            'post_status' => 'draft',
            'post_title' => $source_post->post_title,
            'post_excerpt' => $source_post->post_excerpt,
            'post_content' => $source_post->post_content,
        ]);

        if (is_wp_error($new_post_id) || !$new_post_id) {
            continue;
        }

        update_post_meta($new_post_id, '_repeat_source_id', $post_id);

        foreach ($fields as $field_name => $field_value) {
            update_field($field_name, $field_value, $new_post_id);
        }

        update_field('eventDate', $next_date_value, $new_post_id);
        $created++;
    }

    update_post_meta($post_id, '_repeat_generated_until', $end_date->format('Y-m-d'));

    return $created;
}

/**
 * 2.1 REPEATING EVENTS (ACF FREE COMPATIBLE)
 */
add_filter('acf/validate_value/key=field_repeatUntil', function($valid, $value, $field, $input) {
    if ($valid !== true) {
        return $valid;
    }

    if (!$value) {
        return $valid;
    }

    $event_date_value = null;
    if (isset($_POST['acf']['field_eventDate'])) {
        $event_date_value = $_POST['acf']['field_eventDate'];
    } elseif (function_exists('acf_get_form_data')) {
        $post_id = acf_get_form_data('post_id');
        if ($post_id) {
            $event_date_value = get_field('eventDate', $post_id);
        }
    }

    if (!$event_date_value) {
        return $valid;
    }

    $event_date = DateTimeImmutable::createFromFormat('Y-m-d', $event_date_value);
    $repeat_until = DateTimeImmutable::createFromFormat('Y-m-d', $value);

    if (!$event_date || !$repeat_until) {
        return $valid;
    }

    if ($repeat_until < $event_date) {
        return 'Repeat Until must be on or after Event Date.';
    }

    return $valid;
}, 10, 4);

add_action('acf/save_post', function($post_id) {
    if (get_post_type($post_id) !== 'event') {
        return;
    }

    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }

    kandie_generate_repeats_for_post($post_id, false);
}, 20);

/**
 * 3. PRIVATE GITHUB SILENT AUTO-UPDATER
 */
add_action('plugins_loaded', function () {

    // Prevent fatal errors if Composer is missing
    if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
        return;
    }

    require_once __DIR__ . '/vendor/autoload.php';

    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        return;
    }

    // Build update checker
    $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
        'https://github.com/jeremytai/kandie-gang-grouprides-manager', // ← your GitHub repo URL
        __FILE__,
        'kandie-gang-grouprides-manager' // ← must match your plugin folder name
    );

    // Explicitly set branch (replace 'main' with your branch if different)
    $updateChecker->setBranch('main');

    // Use GitHub Releases
    $updateChecker->getVcsApi()->enableReleaseAssets();

    // Authenticate with GitHub token for private repo
    if (defined('KANDIE_GH_TOKEN') && KANDIE_GH_TOKEN) {
        $updateChecker->setAuthentication(KANDIE_GH_TOKEN);
    }

});

// Auto-update silently
add_filter('auto_update_plugin', function ($update, $item) {
    if ($item->slug === 'kandie-gang-grouprides-manager') {
        return true;
    }
    return $update;
}, 10, 2);

