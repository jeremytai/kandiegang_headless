# Kandie Gang Grouprides Manager

![WordPress](https://img.shields.io/badge/WordPress-6%2B-21759B?logo=wordpress&logoColor=white)
![PHP](https://img.shields.io/badge/PHP-8.0%2B-777BB4?logo=php&logoColor=white)
![ACF](https://img.shields.io/badge/ACF-Required-00A0D2)
![WPGraphQL](https://img.shields.io/badge/WPGraphQL-Supported-E10098)
![Version](https://img.shields.io/badge/Version-4.2.8-blue)
![License](https://img.shields.io/badge/License-Proprietary-red)

A structured WordPress plugin for managing guided rides, workshops, and community cycling events with multi-level ride organization and full WPGraphQL support.

---

## Overview

Kandie Gang Grouprides Manager provides a flexible system for organizing:

- Guided group rides  
- Workshops  
- Multi-level ride structures  
- Community-focused cycling events  

Built for structured data handling and modern headless WordPress setups.

---

## Features

### Custom Post Types

- **Kandie Guides** (`ride_guide`)
- **Events** (`event`)

---

### Event Types

- Groupride  
- Workshop  

---

### Ride Levels (Groupride Only)

Each level supports:

- Multiple guides  
- Distance (km)  
- Route URL  
- GPX file upload  

Available levels:

- Level 1  
- Level 2  
- Level 2+  
- Level 3  

---

### Workshop Fields

- Maximum participant capacity  
- Workshop start time  

---

### Additional Event Data

- Event date  
- Ride category (Road, Gravel, Human Ride)  
- FLINTA* only toggle  
- Public release days before event  
- Repeating event toggle + repeat until date  
- Structured meeting point  
- Markdown description  

---

## GraphQL Integration

All post types and fields are exposed via WPGraphQL, including:

- `rideGuides`
- `rideEvents`
- `eventDetails`

Designed for structured frontend consumption and headless applications.

### Sample GraphQL Query

```graphql
query EventBySlug {
  rideEvent(id: "2026-season-opener", idType: SLUG) {
    title
    excerpt
    publicReleaseDate
    featuredImage {
      node {
        sourceUrl
        altText
      }
    }
    eventDetails {
      primaryType
      rideCategory
      eventDate
      publicReleaseDaysBefore
      repeatingEvent
      repeatUntil
      isFlintaOnly
      description

      meetingPoint {
        name
        street
        city
      }

      level1 {
        distanceKm
        routeUrl
        gpxFile {
          node {
            id
          }
        }
        guides {
          nodes {
            ... on RideGuide {
              title
              featuredImage {
                node {
                  sourceUrl
                  altText
                }
              }
            }
          }
        }
      }
    }
  }
}
```

---

## Requirements

- WordPress 6+
- PHP 8.0+
- Advanced Custom Fields (ACF)
- WPGraphQL

---

## Installation

1. Clone or download the repository.
2. Place the plugin folder inside: wp-content/plugins/
3. Activate the plugin in WordPress Admin.
4. Ensure ACF (free or Pro) is installed and active.

### GPX Uploads

This plugin enables GPX uploads by allowing the GPX MIME type. If your host blocks GPX uploads, check any additional security plugins that filter uploads.

### Repeating Events Tools

An admin page is available at Events → Repeat Tools to regenerate repeat events or delete draft repeats. Repeat generation creates draft events weekly through the selected Repeat Until date.

### One-Time Backfill

On the first admin page load after install/update, the plugin backfills:

- `repeatUntil` for repeating events (default: 2026-10-20)
- `distanceKm` for ride levels when missing (default: 60)

## Private GitHub Auto-Updates

To enable silent auto-updates from your private GitHub repository:

1. Create a Personal Access Token on GitHub:

- Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
- Click Generate new token (classic)
- Select repo scopes (full control of private repositories)
- Copy the generated token

1. Add the token to your wp-config.php:

define('KANDIE_GH_TOKEN', 'ghp_your_token_here');

1. Ensure the plugin folder name matches the one in the updater (kandie-gang-grouprides-manager) and that you have created at least one release matching the plugin version (e.g., 4.2.8). The git tag can be v4.2.8, but the release version should be numeric.
1. The plugin will now check for updates silently.

If Composer dependencies are used:

---

## Development Notes

- All ACF fields are registered programmatically.
- No manual field configuration required.
- Conditional logic controls event-type-specific fields.
- Designed for scalable frontend integrations.

---

## Versioning

This project follows semantic versioning:
MAJOR.MINOR.PATCH

Example:

- 4.0.0 – Major feature release  
- 4.1.0 – Feature addition  
- 4.1.1 – Bug fix  

### Migration Notes

- `publicReleaseDate` is now computed and exposed at the `rideEvent` level in GraphQL.
- The ACF field `publicReleaseDate` was replaced by `publicReleaseDaysBefore` (and `repeatUntil` for repeating events).

---

## License

Proprietary software.  
All rights reserved.

---

## Author

Kandie Kollektiv UG (haftungsbeschränkt)
