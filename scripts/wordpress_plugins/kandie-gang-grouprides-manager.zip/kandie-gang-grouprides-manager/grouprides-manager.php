<?php
/**
 * Plugin Name: Kandie Gang GroupRide & Events Manager
 * Description: Multi-level ride management (7 spots per guide), Workshops, and "Human Ride" category. Unified for GraphQL.
 * Version: 4.3.2
 * Author: Kandie Kollektiv UG (haftungsbeschränkt)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter('upload_mimes', function($mimes) {
    $mimes['gpx'] = 'application/gpx+xml';
    $mimes['gpxxml'] = 'application/gpx+xml';
    $mimes['application/gpx+xml'] = 'application/gpx+xml';
    $mimes['octet-stream'] = 'application/octet-stream';
    $mimes['application/octet-stream'] = 'application/octet-stream';
    return $mimes;
});

/**
 * 1. REGISTER CUSTOM POST TYPES
 */
add_action( 'init', function() {
    register_post_type( 'ride_guide', [
        'labels' => [ 'name' => 'Kandie Guides', 'singular_name' => 'Guide' ],
        'public' => true,
        'menu_icon' => 'dashicons-admin-users',
        'supports' => [ 'title', 'thumbnail' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideGuide',
        'graphql_plural_name' => 'rideGuides',
    ]);

    register_post_type( 'event', [
        'labels' => [ 
            'name' => 'Kandie Gang Events', 
            'singular_name' => 'Event',
            'add_new_item' => 'Add New Kandie Gang Event'
        ],
        'public' => true,
        'menu_icon' => 'dashicons-performance',
        'supports' => [ 'title', 'thumbnail', 'excerpt' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideEvent',
        'graphql_plural_name' => 'rideEvents',
    ]);
});

/**
 * 2. REGISTER ACF FIELDS
 */
add_action('acf/init', function() {
    if( !function_exists('acf_add_local_field_group') ) return;

    $fields = [];

    // --- BASIC CONFIG ---
    $fields[] = [
        'key' => 'field_primaryType',
        'label' => 'Event Type',
        'name' => 'primaryType',
        'type' => 'radio',
        'choices' => ['groupride' => 'Groupride', 'workshop' => 'Workshop'],
        'layout' => 'horizontal',
        'return_format' => 'label',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_rideCategory',
        'label' => 'Ride Category',
        'name' => 'rideCategory',
        'type' => 'select',
        'choices' => ['road' => 'Road', 'gravel' => 'Gravel', 'human_ride' => 'Human Ride'],
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'return_format' => 'label',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_eventDate',
        'label' => 'Event Date',
        'name' => 'eventDate',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_rideTime',
        'label' => 'Ride Time',
        'name' => 'rideTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_publicReleaseDaysBefore',
        'label' => 'Public Release Days Before Event',
        'name' => 'publicReleaseDaysBefore',
        'type' => 'number',
        'default_value' => 7,
        'min' => 0,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_repeatingEvent',
        'label' => 'Repeating Event?',
        'name' => 'repeatingEvent',
        'type' => 'true_false',
        'ui' => 1,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_repeatUntil',
        'label' => 'Repeat Until',
        'name' => 'repeatUntil',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'conditional_logic' => [[['field' => 'field_repeatingEvent', 'operator' => '==', 'value' => '1']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_isFlintaOnly',
        'label' => 'FLINTA* Only?',
        'name' => 'isFlintaOnly',
        'type' => 'true_false',
        'ui' => 1,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_meetingPoint',
        'label' => 'Meeting Point',
        'name' => 'meetingPoint',
        'type' => 'group',
        'show_in_graphql' => true,
        'sub_fields' => [
            ['key' => 'f_mp_name', 'label' => 'Place Name', 'name' => 'name', 'type' => 'text', 'show_in_graphql' => true],
            ['key' => 'f_mp_street', 'label' => 'Street', 'name' => 'street', 'type' => 'text', 'show_in_graphql' => true],
            ['key' => 'f_mp_city', 'label' => 'City', 'name' => 'city', 'type' => 'text', 'show_in_graphql' => true],
        ],
    ];

    $fields[] = [
        'key' => 'field_workshopCapacity',
        'label' => 'Maximum Workshop Participants',
        'name' => 'workshopCapacity',
        'type' => 'number',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'workshop']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_workshopStartTime',
        'label' => 'Workshop Start Time',
        'name' => 'workshopStartTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'workshop']]],
        'show_in_graphql' => true,
    ];

    // --- RIDE LEVELS ---
    $levels = ['level1' => '1', 'level2' => '2', 'level2plus' => '2+', 'level3' => '3'];
    foreach ($levels as $name => $label) {
        $fields[] = [
            'key' => "field_group_$name",
            'label' => "Level $label Details",
            'name' => $name,
            'type' => 'group',
            'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
            'show_in_graphql' => true,
            'sub_fields' => [
                [
                    'key' => "f_{$name}_guides",
                    'label' => 'Guides',
                    'name' => 'guides',
                    'type' => 'post_object',
                    'post_type' => ['ride_guide'],
                    'multiple' => 1,
                    'return_format' => 'object',
                    'ui' => 1,
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_distanceKm",
                    'label' => 'Distance (km)',
                    'name' => 'distanceKm',
                    'type' => 'number',
                    'required' => 0, // Explicitly not required
                    'min' => 0,
                    'step' => 0.1,
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_routeUrl",
                    'label' => 'Route URL',
                    'name' => 'routeUrl',
                    'type' => 'url',
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_gpxFile",
                    'label' => 'GPX File URL',
                    'name' => 'gpxFile',
                    'type' => 'url',
                    'show_in_graphql' => true,
                ],
            ],
        ];
    }

    $fields[] = [
        'key' => 'field_description',
        'label' => 'Description',
        'name' => 'description',
        'type' => 'textarea',
        'show_in_graphql' => true,
    ];

    acf_add_local_field_group([
        'key' => 'group_ride_manager_final',
        'title' => 'Event Details',
        'fields' => $fields,
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'event']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'eventDetails',
    ]);

    acf_add_local_field_group([
        'key' => 'group_ride_guides_details',
        'title' => 'Guide Details',
        'fields' => [
            ['key' => 'field_guide_bio', 'label' => 'Bio', 'name' => 'bio', 'type' => 'textarea', 'show_in_graphql' => true],
            ['key' => 'field_guide_link', 'label' => 'Link', 'name' => 'link', 'type' => 'text', 'show_in_graphql' => true],
        ],
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'ride_guide']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'guideDetails',
    ]);
});

/**
 * 3. GRAPHQL CUSTOM FIELDS & RESOLVERS
 */
add_action('graphql_register_types', function() {
    if (!function_exists('register_graphql_field')) return;

    // Capitalized primaryType Resolver
    register_graphql_field('RideEvent_Eventdetails', 'primaryType', [
        'type' => 'String',
        'resolve' => function($root) {
            $val = get_field('primaryType', $root->ID ?? $root->databaseId);
            return $val ? ucfirst(str_replace('_', ' ', $val)) : null;
        }
    ]);

    // Capitalized & Cleaned rideCategory Resolver
    register_graphql_field('RideEvent_Eventdetails', 'rideCategory', [
        'type' => 'String',
        'resolve' => function($root) {
            $val = get_field('rideCategory', $root->ID ?? $root->databaseId);
            $single = is_array($val) ? $val[0] : $val;
            return $single ? ucfirst(str_replace('_', ' ', $single)) : null;
        }
    ]);

    register_graphql_field('RideEvent', 'publicReleaseDate', [
        'type' => 'String',
        'resolve' => function($root) {
            $post_id = $root->databaseId ?? $root->ID;
            $event_date = get_field('eventDate', $post_id);
            $days = get_field('publicReleaseDaysBefore', $post_id) ?: 7;
            $dt = DateTimeImmutable::createFromFormat('Y-m-d', $event_date);
            return $dt ? $dt->modify("-{$days} days")->format('Y-m-d') : null;
        }
    ]);

    register_graphql_field('RideEvent', 'eventDateTime', [
        'type' => 'String',
        'resolve' => function($root) {
            $post_id = $root->databaseId ?? $root->ID;
            $date = get_field('eventDate', $post_id);
            $time = get_field('rideTime', $post_id);
            if (!$date || !$time) return null;
            $dt = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', "$date " . (strlen($time) == 5 ? "$time:00" : $time), new DateTimeZone('UTC'));
            return $dt ? $dt->format('c') : null;
        }
    ]);
});

/**
 * 4. BACKFILL & REPEAT TOOLS
 */
add_action('admin_init', function() {
    if (!is_admin() || get_option('kandie_v4_3_2_distance_fix')) return;
    update_option('kandie_v4_3_2_distance_fix', 1);
});

function kandie_generate_repeats($post_id) {
    if (get_post_type($post_id) !== 'event' || get_post_meta($post_id, '_repeat_source_id', true)) return;
    $start_val = get_field('eventDate', $post_id);
    $end_val = get_field('repeatUntil', $post_id);
    if (!$start_val || !$end_val) return;
    $start = DateTimeImmutable::createFromFormat('Y-m-d', $start_val);
    $end = DateTimeImmutable::createFromFormat('Y-m-d', $end_val);
    $fields = get_fields($post_id) ?: [];
    
    for ($next = $start->modify('+7 days'); $next <= $end; $next = $next->modify('+7 days')) {
        $new_id = wp_insert_post(['post_type' => 'event', 'post_status' => 'draft', 'post_title' => get_the_title($post_id)]);
        if ($new_id) {
            update_post_meta($new_id, '_repeat_source_id', $post_id);
            foreach ($fields as $k => $v) update_field($k, $v, $new_id);
            update_field('eventDate', $next->format('Y-m-d'), $new_id);
        }
    }
}

add_action('acf/save_post', 'kandie_generate_repeats', 20);

/**
 * 5. AUTO-UPDATER
 */
add_action('plugins_loaded', function () {
    if (!file_exists(__DIR__ . '/vendor/autoload.php')) return;
    require_once __DIR__ . '/vendor/autoload.php';
    $puc = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker('https://github.com/jeremytai/kandie-gang-grouprides-manager', __FILE__, 'kandie-gang-grouprides-manager');
    if (defined('KANDIE_GH_TOKEN')) $puc->setAuthentication(KANDIE_GH_TOKEN);
});