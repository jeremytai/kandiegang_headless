<?php
/**
 * Plugin Name: Kandie Gang GroupRide & Events Manager
 * Description: Multi-level ride management (7 spots per guide), Workshops, and "Human Ride" category. Unified for GraphQL.
 * Version: 4.4.0
 * Author: Kandie Kollektiv UG (haftungsbeschränkt)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter('upload_mimes', function($mimes) {
    $mimes['gpx'] = 'application/gpx+xml';
    $mimes['gpxxml'] = 'application/gpx+xml';
    $mimes['application/gpx+xml'] = 'application/gpx+xml';
    $mimes['octet-stream'] = 'application/octet-stream';
    $mimes['application/octet-stream'] = 'application/octet-stream';
    return $mimes;
});

/**
 * 1. REGISTER CUSTOM POST TYPES
 */
add_action( 'init', function() {
    register_post_type( 'ride_guide', [
        'labels' => [ 'name' => 'Kandie Guides', 'singular_name' => 'Guide' ],
        'public' => true,
        'menu_icon' => 'dashicons-admin-users',
        'supports' => [ 'title', 'thumbnail' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideGuide',
        'graphql_plural_name' => 'rideGuides',
    ]);

    register_post_type( 'event', [
        'labels' => [ 
            'name' => 'Kandie Gang Events', 
            'singular_name' => 'Event',
            'add_new_item' => 'Add New Kandie Gang Event'
        ],
        'public' => true,
        'menu_icon' => 'dashicons-performance',
        'supports' => [ 'title', 'thumbnail', 'excerpt' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideEvent',
        'graphql_plural_name' => 'rideEvents',
    ]);

    // Occurrences: one per date (weekly), editable in admin, resolved via GraphQL
    register_post_type( 'event_occurrence', [
        'labels' => [
            'name' => 'Event Occurrences',
            'singular_name' => 'Event Occurrence',
            'add_new_item' => 'Add New Occurrence',
        ],
        // Visible in admin, not publicly queryable as a standalone page.
        'public' => false,
        'publicly_queryable' => false,
        'exclude_from_search' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-calendar-alt',
        'supports' => [ 'title' ],
        'show_in_graphql' => true,
        'graphql_single_name' => 'rideEventOccurrence',
        'graphql_plural_name' => 'rideEventOccurrences',
    ]);
});

/**
 * 2. REGISTER ACF FIELDS
 */
add_action('acf/init', function() {
    if( !function_exists('acf_add_local_field_group') ) return;

    $fields = [];

    // --- BASIC CONFIG ---
    $fields[] = [
        'key' => 'field_primaryType',
        'label' => 'Event Type',
        'name' => 'primaryType',
        'type' => 'radio',
        'choices' => ['groupride' => 'Groupride', 'workshop' => 'Workshop'],
        'layout' => 'horizontal',
        'return_format' => 'label',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_rideCategory',
        'label' => 'Ride Category',
        'name' => 'rideCategory',
        'type' => 'select',
        'choices' => ['road' => 'Road', 'gravel' => 'Gravel', 'human_ride' => 'Human Ride'],
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'return_format' => 'label',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_eventDate',
        'label' => 'Event Date',
        'name' => 'eventDate',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_rideTime',
        'label' => 'Ride Time',
        'name' => 'rideTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride']]],
        'show_in_graphql' => true,
    ];

    // Guides + pace for gravel grouprides (no levels)
    $fields[] = [
        'key' => 'field_gravelGuides',
        'label' => 'Guides',
        'name' => 'gravelGuides',
        'type' => 'post_object',
        'post_type' => ['ride_guide'],
        'multiple' => 1,
        'return_format' => 'object',
        'ui' => 1,
        'conditional_logic' => [[
            ['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride'],
            ['field' => 'field_rideCategory', 'operator' => '==', 'value' => 'gravel'],
        ]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_gravelPace',
        'label' => 'Pace',
        'name' => 'gravelPace',
        'type' => 'text',
        'instructions' => 'Average pace (e.g. 25–28 km/h)',
        'conditional_logic' => [[
            ['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride'],
            ['field' => 'field_rideCategory', 'operator' => '==', 'value' => 'gravel'],
        ]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_gravelDistanceKm',
        'label' => 'Distance (km)',
        'name' => 'gravelDistanceKm',
        'type' => 'number',
        'required' => 0,
        'min' => 0,
        'step' => 0.1,
        'conditional_logic' => [[
            ['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride'],
            ['field' => 'field_rideCategory', 'operator' => '==', 'value' => 'gravel'],
        ]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_gravelRouteUrl',
        'label' => 'Route URL',
        'name' => 'gravelRouteUrl',
        'type' => 'url',
        'conditional_logic' => [[
            ['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride'],
            ['field' => 'field_rideCategory', 'operator' => '==', 'value' => 'gravel'],
        ]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_publicReleaseDaysBefore',
        'label' => 'Public Release Days Before Event',
        'name' => 'publicReleaseDaysBefore',
        'type' => 'number',
        'default_value' => 7,
        'min' => 0,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_repeatingEvent',
        'label' => 'Repeating Event?',
        'name' => 'repeatingEvent',
        'type' => 'true_false',
        'ui' => 1,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_repeatUntil',
        'label' => 'Repeat Until',
        'name' => 'repeatUntil',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'conditional_logic' => [[['field' => 'field_repeatingEvent', 'operator' => '==', 'value' => '1']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_isFlintaOnly',
        'label' => 'FLINTA* Only?',
        'name' => 'isFlintaOnly',
        'type' => 'true_false',
        'ui' => 1,
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_meetingPoint',
        'label' => 'Meeting Point',
        'name' => 'meetingPoint',
        'type' => 'group',
        'show_in_graphql' => true,
        'sub_fields' => [
            ['key' => 'f_mp_name', 'label' => 'Place Name', 'name' => 'name', 'type' => 'text', 'show_in_graphql' => true],
            ['key' => 'f_mp_street', 'label' => 'Street', 'name' => 'street', 'type' => 'text', 'show_in_graphql' => true],
            ['key' => 'f_mp_city', 'label' => 'City', 'name' => 'city', 'type' => 'text', 'show_in_graphql' => true],
        ],
    ];

    $fields[] = [
        'key' => 'field_workshopCapacity',
        'label' => 'Maximum Workshop Participants',
        'name' => 'workshopCapacity',
        'type' => 'number',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'workshop']]],
        'show_in_graphql' => true,
    ];

    $fields[] = [
        'key' => 'field_workshopStartTime',
        'label' => 'Workshop Start Time',
        'name' => 'workshopStartTime',
        'type' => 'time_picker',
        'conditional_logic' => [[['field' => 'field_primaryType', 'operator' => '==', 'value' => 'workshop']]],
        'show_in_graphql' => true,
    ];

    // --- RIDE LEVELS ---
    $levels = ['level1' => '1', 'level2' => '2', 'level2plus' => '2+', 'level3' => '3'];
    foreach ($levels as $name => $label) {
        $fields[] = [
            'key' => "field_group_$name",
            'label' => "Level $label Details",
            'name' => $name,
            'type' => 'group',
            'conditional_logic' => [[
                ['field' => 'field_primaryType', 'operator' => '==', 'value' => 'groupride'],
                ['field' => 'field_rideCategory', 'operator' => '!=', 'value' => 'gravel'],
            ]],
            'show_in_graphql' => true,
            'sub_fields' => [
                [
                    'key' => "f_{$name}_guides",
                    'label' => 'Guides',
                    'name' => 'guides',
                    'type' => 'post_object',
                    'post_type' => ['ride_guide'],
                    'multiple' => 1,
                    'return_format' => 'object',
                    'ui' => 1,
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_distanceKm",
                    'label' => 'Distance (km)',
                    'name' => 'distanceKm',
                    'type' => 'number',
                    'required' => 0, // Explicitly not required
                    'min' => 0,
                    'step' => 0.1,
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_routeUrl",
                    'label' => 'Route URL',
                    'name' => 'routeUrl',
                    'type' => 'url',
                    'show_in_graphql' => true,
                ],
                [
                    'key' => "f_{$name}_gpxFile",
                    'label' => 'GPX File URL',
                    'name' => 'gpxFile',
                    'type' => 'url',
                    'show_in_graphql' => true,
                ],
            ],
        ];
    }

    $fields[] = [
        'key' => 'field_description',
        'label' => 'Description',
        'name' => 'description',
        'type' => 'textarea',
        'show_in_graphql' => true,
    ];

    acf_add_local_field_group([
        'key' => 'group_ride_manager_final',
        'title' => 'Event Details',
        'fields' => $fields,
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'event']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'eventDetails',
    ]);

    // --- OCCURRENCE FIELDS (per-date guide assignments) ---
    $occurrence_fields = [];

    $occurrence_fields[] = [
        'key' => 'field_occ_seriesEvent',
        'label' => 'Series Event',
        'name' => 'seriesEvent',
        'type' => 'post_object',
        'post_type' => ['event'],
        'multiple' => 0,
        'return_format' => 'object',
        'ui' => 1,
        'required' => 1,
        'show_in_graphql' => true,
    ];

    $occurrence_fields[] = [
        'key' => 'field_occ_occurrenceDate',
        'label' => 'Occurrence Date',
        'name' => 'occurrenceDate',
        'type' => 'date_picker',
        'display_format' => 'd/m/Y',
        'return_format' => 'Y-m-d',
        'required' => 1,
        'show_in_graphql' => true,
    ];

    // Guides per level for this occurrence (copied from Series defaults; editable week-by-week)
    $occLevels = [
        'occurrenceLevel1Guides' => 'Level 1 Guides',
        'occurrenceLevel2Guides' => 'Level 2 Guides',
        'occurrenceLevel2plusGuides' => 'Level 2+ Guides',
        'occurrenceLevel3Guides' => 'Level 3 Guides',
        'occurrenceGravelGuides' => 'Gravel Guides',
    ];

    foreach ($occLevels as $name => $label) {
        $occurrence_fields[] = [
            'key' => "field_occ_$name",
            'label' => $label,
            'name' => $name,
            'type' => 'post_object',
            'post_type' => ['ride_guide'],
            'multiple' => 1,
            'return_format' => 'object',
            'ui' => 1,
            'show_in_graphql' => true,
        ];
    }

    acf_add_local_field_group([
        'key' => 'group_event_occurrence_details',
        'title' => 'Occurrence Details',
        'fields' => $occurrence_fields,
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'event_occurrence']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'occurrenceDetails',
    ]);

    acf_add_local_field_group([
        'key' => 'group_ride_guides_details',
        'title' => 'Guide Details',
        'fields' => [
            ['key' => 'field_guide_bio', 'label' => 'Bio', 'name' => 'bio', 'type' => 'textarea', 'show_in_graphql' => true],
            ['key' => 'field_guide_link', 'label' => 'Link', 'name' => 'link', 'type' => 'text', 'show_in_graphql' => true],
        ],
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'ride_guide']]],
        'show_in_graphql' => true,
        'graphql_field_name' => 'guideDetails',
    ]);
});

/**
 * 3. GRAPHQL CUSTOM FIELDS & RESOLVERS
 */
add_action('graphql_register_types', function() {
    if (!function_exists('register_graphql_field')) return;

    // Capitalized primaryType Resolver
    register_graphql_field('RideEvent_Eventdetails', 'primaryType', [
        'type' => 'String',
        'resolve' => function($root) {
            $val = get_field('primaryType', $root->ID ?? $root->databaseId);
            return $val ? ucfirst(str_replace('_', ' ', $val)) : null;
        }
    ]);

    // Capitalized & Cleaned rideCategory Resolver
    register_graphql_field('RideEvent_Eventdetails', 'rideCategory', [
        'type' => 'String',
        'resolve' => function($root) {
            $val = get_field('rideCategory', $root->ID ?? $root->databaseId);
            $single = is_array($val) ? $val[0] : $val;
            return $single ? ucfirst(str_replace('_', ' ', $single)) : null;
        }
    ]);

    register_graphql_field('RideEvent', 'publicReleaseDate', [
        'type' => 'String',
        'resolve' => function($root) {
            $post_id = $root->databaseId ?? $root->ID;
            $event_date = get_field('eventDate', $post_id);
            $days = get_field('publicReleaseDaysBefore', $post_id) ?: 7;
            $dt = DateTimeImmutable::createFromFormat('Y-m-d', $event_date);
            return $dt ? $dt->modify("-{$days} days")->format('Y-m-d') : null;
        }
    ]);

    register_graphql_field('RideEvent', 'eventDateTime', [
        'type' => 'String',
        'resolve' => function($root) {
            $post_id = $root->databaseId ?? $root->ID;
            $date = get_field('eventDate', $post_id);
            $time = get_field('rideTime', $post_id);
            if (!$date || !$time) return null;
            $dt = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', "$date " . (strlen($time) == 5 ? "$time:00" : $time), new DateTimeZone('UTC'));
            return $dt ? $dt->format('c') : null;
        }
    ]);

    // Resolve the occurrence for a given series event and date (Y-m-d).
    // Keeps `/event/:yy/:mm/:dd/:slug` working while allowing week-by-week guide assignments.
    register_graphql_field('RideEvent', 'occurrenceByDate', [
        'type' => 'RideEventOccurrence',
        'args' => [
            'date' => [
                'type' => 'String',
                'description' => 'Occurrence date in Y-m-d format (e.g. 2026-04-21)',
            ],
        ],
        'resolve' => function($root, $args) {
            $series_id = $root->databaseId ?? $root->ID;
            $date = isset($args['date']) ? $args['date'] : null;
            if (!$series_id || !$date) return null;

            $q = new WP_Query([
                'post_type' => 'event_occurrence',
                'post_status' => ['publish', 'draft'],
                'posts_per_page' => 1,
                'fields' => 'ids',
                'meta_query' => [
                    'relation' => 'AND',
                    [
                        'key' => 'seriesEvent',
                        'value' => (int) $series_id,
                        'compare' => '=',
                    ],
                    [
                        'key' => 'occurrenceDate',
                        'value' => $date,
                        'compare' => '=',
                    ],
                ],
            ]);

            if (empty($q->posts)) return null;
            return get_post($q->posts[0]);
        },
    ]);
});

/**
 * 4. BACKFILL & REPEAT TOOLS
 */
add_action('admin_init', function() {
    if (!is_admin() || get_option('kandie_v4_3_2_distance_fix')) return;
    update_option('kandie_v4_3_2_distance_fix', 1);
});

function kandie_generate_repeats($post_id) {
    if (get_post_type($post_id) !== 'event') return;

    // Only generate occurrences for series events explicitly marked as repeating.
    $is_repeating = (bool) get_field('repeatingEvent', $post_id);
    if (!$is_repeating) return;

    $start_val = get_field('eventDate', $post_id);
    $end_val = get_field('repeatUntil', $post_id);
    if (!$start_val || !$end_val) return;

    $start = DateTimeImmutable::createFromFormat('Y-m-d', $start_val);
    $end = DateTimeImmutable::createFromFormat('Y-m-d', $end_val);
    if (!$start || !$end) return;

    // Determine series defaults (used as copy-to-occurrence seed)
    $ride_category = get_field('rideCategory', $post_id);
    $ride_category_single = is_array($ride_category) ? ($ride_category[0] ?? null) : $ride_category;
    $is_gravel = $ride_category_single === 'gravel';

    $default_gravel_guides = get_field('gravelGuides', $post_id);
    $default_level_guides = [
        'occurrenceLevel1Guides' => null,
        'occurrenceLevel2Guides' => null,
        'occurrenceLevel2plusGuides' => null,
        'occurrenceLevel3Guides' => null,
    ];

    if (!$is_gravel) {
        foreach (['level1','level2','level2plus','level3'] as $level_key) {
            $level_val = get_field($level_key, $post_id);
            $guides = is_array($level_val) && isset($level_val['guides']) ? $level_val['guides'] : null;
            if ($level_key === 'level1') $default_level_guides['occurrenceLevel1Guides'] = $guides;
            if ($level_key === 'level2') $default_level_guides['occurrenceLevel2Guides'] = $guides;
            if ($level_key === 'level2plus') $default_level_guides['occurrenceLevel2plusGuides'] = $guides;
            if ($level_key === 'level3') $default_level_guides['occurrenceLevel3Guides'] = $guides;
        }
    }

    // Generate from start date through end date inclusive, in weekly increments.
    for ($next = $start; $next <= $end; $next = $next->modify('+7 days')) {
        $date_str = $next->format('Y-m-d');

        // Avoid duplicates if an occurrence already exists for this series+date.
        $existing = new WP_Query([
            'post_type' => 'event_occurrence',
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'seriesEvent',
                    'value' => (int) $post_id,
                    'compare' => '=',
                ],
                [
                    'key' => 'occurrenceDate',
                    'value' => $date_str,
                    'compare' => '=',
                ],
            ],
        ]);

        if (!empty($existing->posts)) continue;

        $new_title = get_the_title($post_id) . ' — ' . $next->format('Y-m-d');
        $new_id = wp_insert_post([
            'post_type' => 'event_occurrence',
            'post_status' => 'draft',
            'post_title' => $new_title,
        ]);

        if (!$new_id) continue;

        // Link occurrence to series and set date.
        update_field('seriesEvent', $post_id, $new_id);
        update_field('occurrenceDate', $date_str, $new_id);

        // Copy default guides from series as starting point.
        if ($is_gravel) {
            update_field('occurrenceGravelGuides', $default_gravel_guides, $new_id);
        } else {
            foreach ($default_level_guides as $field_name => $guides_val) {
                update_field($field_name, $guides_val, $new_id);
            }
        }
    }
}

add_action('acf/save_post', 'kandie_generate_repeats', 20);

/**
 * 5. AUTO-UPDATER
 */
add_action('plugins_loaded', function () {
    if (!file_exists(__DIR__ . '/vendor/autoload.php')) return;
    require_once __DIR__ . '/vendor/autoload.php';
    $puc = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker('https://github.com/jeremytai/kandie-gang-grouprides-manager', __FILE__, 'kandie-gang-grouprides-manager');
    if (defined('KANDIE_GH_TOKEN')) $puc->setAuthentication(KANDIE_GH_TOKEN);
});